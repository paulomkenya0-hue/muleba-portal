import 'package:flutter/material.dart';
import '../../database/database_helper.dart';
import '../../models/models.dart';
import '../../theme/app_theme.dart';
import '../../utils/validators.dart';
import '../../widgets/common_widgets.dart';
import '../../widgets/leader_edit_dialog.dart';

class DivisionsScreen extends StatefulWidget {
  const DivisionsScreen({super.key});

  @override
  State<DivisionsScreen> createState() => _DivisionsScreenState();
}

class _DivisionsScreenState extends State<DivisionsScreen> {
  List<Division> _divisions = [];
  bool _loading = true;
  int? _expandedDivisionId;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final divisions = await DatabaseHelper.instance.getDivisions();
    if (mounted) setState(() { _divisions = divisions; _loading = false; });
  }

  void _showAddEdit({Division? division}) {
    showDialog(
      context: context,
      builder: (_) => _DivisionFormDialog(
        division: division,
        onSaved: _load,
      ),
    );
  }

  Future<void> _delete(Division division) async {
    final confirm = await showConfirmDialog(
      context,
      title: 'Futa Tarafa',
      message: 'Una uhakika wa kufuta "${division.name}"?\n\nVita zote, Kata na Viongozi wa Tarafa hii vitafutwa.',
    );
    if (confirm == true) {
      await DatabaseHelper.instance.deleteDivision(division.id!);
      _load();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text(AppStrings.deletedSuccess)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceWhite,
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SectionHeader(title: 'Tarafa (${_divisions.length})'),
                const Spacer(),
                ElevatedButton.icon(
                  onPressed: () => _showAddEdit(),
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text(AppStrings.addDivision),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _divisions.isEmpty
                      ? EmptyState(
                          message: 'Hakuna Tarafa bado.\nOngeza Tarafa ya kwanza.',
                          icon: Icons.location_city_outlined,
                          actionLabel: AppStrings.addDivision,
                          onAction: () => _showAddEdit(),
                        )
                      : ListView.builder(
                          itemCount: _divisions.length,
                          itemBuilder: (context, index) {
                            final div = _divisions[index];
                            return _DivisionCard(
                              division: div,
                              isExpanded: _expandedDivisionId == div.id,
                              onToggleExpand: () => setState(() {
                                _expandedDivisionId = _expandedDivisionId == div.id ? null : div.id;
                              }),
                              onEdit: () => _showAddEdit(division: div),
                              onDelete: () => _delete(div),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DivisionCard extends StatelessWidget {
  final Division division;
  final bool isExpanded;
  final VoidCallback onToggleExpand;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _DivisionCard({
    required this.division,
    required this.isExpanded,
    required this.onToggleExpand,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Column(
        children: [
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            leading: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: AppTheme.lightGreen,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.location_city, color: AppTheme.primaryGreen, size: 22),
            ),
            title: Text(
              division.name,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
            ),
            subtitle: division.description != null && division.description!.isNotEmpty
                ? Text(division.description!, style: const TextStyle(color: AppTheme.textMuted))
                : null,
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  onPressed: onEdit,
                  icon: const Icon(Icons.edit_outlined),
                  tooltip: 'Hariri',
                  color: AppTheme.primaryGreen,
                ),
                IconButton(
                  onPressed: onDelete,
                  icon: const Icon(Icons.delete_outline),
                  tooltip: 'Futa',
                  color: AppTheme.errorRed,
                ),
                IconButton(
                  onPressed: onToggleExpand,
                  icon: Icon(isExpanded ? Icons.expand_less : Icons.expand_more),
                  tooltip: 'Viongozi',
                  color: AppTheme.textMuted,
                ),
              ],
            ),
          ),
          if (isExpanded)
            _DivisionLeadersPanel(divisionId: division.id!),
        ],
      ),
    );
  }
}

class _DivisionLeadersPanel extends StatefulWidget {
  final int divisionId;

  const _DivisionLeadersPanel({required this.divisionId});

  @override
  State<_DivisionLeadersPanel> createState() => _DivisionLeadersPanelState();
}

class _DivisionLeadersPanelState extends State<_DivisionLeadersPanel> {
  List<Leader> _leaders = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final leaders = await DatabaseHelper.instance.getLeaders(widget.divisionId, 'division');
    if (mounted) setState(() { _leaders = leaders; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFFF9FAF9),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(12)),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'VIONGOZI WA TARAFA',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: AppTheme.primaryGreen,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 12),
          if (_loading)
            const Center(child: CircularProgressIndicator())
          else
            ...(_leaders.map((leader) => LeaderTile(
                  leader: leader,
                  onEdit: () => showDialog(
                    context: context,
                    builder: (_) => LeaderEditDialog(leader: leader, onSaved: _load),
                  ),
                ))),
        ],
      ),
    );
  }
}

// ─── Division Form Dialog ────────────────────────────────────────────────────
class _DivisionFormDialog extends StatefulWidget {
  final Division? division;
  final VoidCallback onSaved;

  const _DivisionFormDialog({this.division, required this.onSaved});

  @override
  State<_DivisionFormDialog> createState() => _DivisionFormDialogState();
}

class _DivisionFormDialogState extends State<_DivisionFormDialog> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameCtrl;
  late TextEditingController _descCtrl;
  bool _saving = false;

  bool get _isEdit => widget.division != null;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.division?.name ?? '');
    _descCtrl = TextEditingController(text: widget.division?.description ?? '');
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      if (_isEdit) {
        await DatabaseHelper.instance.updateDivision(
          widget.division!.copyWith(
            name: _nameCtrl.text.trim(),
            description: _descCtrl.text.trim().isEmpty ? null : _descCtrl.text.trim(),
          ),
        );
      } else {
        await DatabaseHelper.instance.insertDivision(
          Division(
            name: _nameCtrl.text.trim(),
            description: _descCtrl.text.trim().isEmpty ? null : _descCtrl.text.trim(),
            createdAt: DateTime.now(),
          ),
        );
      }
      if (mounted) {
        widget.onSaved();
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text(AppStrings.savedSuccess)),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 480),
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _isEdit ? 'Hariri Tarafa' : 'Ongeza Tarafa',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 24),
                TextFormField(
                  controller: _nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Jina la Tarafa *',
                    prefixIcon: Icon(Icons.location_city_outlined),
                  ),
                  textCapitalization: TextCapitalization.words,
                  validator: (v) => Validators.validateRequired(v, 'Jina la Tarafa'),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Maelezo (Hiari)',
                    prefixIcon: Icon(Icons.notes_outlined),
                  ),
                  maxLines: 2,
                ),
                const SizedBox(height: 28),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Ghairi'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _saving ? null : _save,
                        child: _saving
                            ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                            : Text(_isEdit ? 'Hifadhi' : 'Ongeza'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
