import 'package:flutter/material.dart';
import '../../database/database_helper.dart';
import '../../models/models.dart';
import '../../theme/app_theme.dart';
import '../../utils/validators.dart';
import '../../widgets/common_widgets.dart';
import '../../widgets/leader_edit_dialog.dart';

class WardsScreen extends StatefulWidget {
  const WardsScreen({super.key});

  @override
  State<WardsScreen> createState() => _WardsScreenState();
}

class _WardsScreenState extends State<WardsScreen> {
  List<Division> _divisions = [];
  Map<int, List<Ward>> _wardsByDivision = {};
  bool _loading = true;
  Set<int> _expandedDivisions = {};
  int? _expandedWardId;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final divisions = await DatabaseHelper.instance.getDivisions();
    final wardMap = <int, List<Ward>>{};
    for (final div in divisions) {
      wardMap[div.id!] = await DatabaseHelper.instance.getWardsByDivision(div.id!);
    }
    if (mounted) setState(() {
      _divisions = divisions;
      _wardsByDivision = wardMap;
      _loading = false;
    });
  }

  void _showAddEdit({Ward? ward, int? divisionId}) {
    if (_divisions.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ongeza Tarafa kwanza kabla ya kuongeza Kata')),
      );
      return;
    }
    showDialog(
      context: context,
      builder: (_) => _WardFormDialog(
        ward: ward,
        divisions: _divisions,
        initialDivisionId: divisionId ?? (ward?.divisionId ?? _divisions.first.id!),
        onSaved: _load,
      ),
    );
  }

  Future<void> _deleteWard(Ward ward) async {
    final confirm = await showConfirmDialog(
      context,
      title: 'Futa Kata',
      message: 'Una uhakika wa kufuta "${ward.name}"?\n\nViongozi wote wa Kata hii watafutwa.',
    );
    if (confirm == true) {
      await DatabaseHelper.instance.deleteWard(ward.id!);
      _load();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text(AppStrings.deletedSuccess)),
      );
    }
  }

  int get _totalWards => _wardsByDivision.values.fold(0, (sum, wards) => sum + wards.length);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceWhite,
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SectionHeader(title: 'Kata ($_totalWards) katika Tarafa ${_divisions.length}'),
                const Spacer(),
                ElevatedButton.icon(
                  onPressed: () => _showAddEdit(),
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text(AppStrings.addWard),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _divisions.isEmpty
                      ? const EmptyState(
                          message: 'Ongeza Tarafa kwanza ili uweze kuongeza Kata',
                          icon: Icons.map_outlined,
                        )
                      : ListView.builder(
                          itemCount: _divisions.length,
                          itemBuilder: (context, i) {
                            final div = _divisions[i];
                            final wards = _wardsByDivision[div.id] ?? [];
                            final isExpanded = _expandedDivisions.contains(div.id);
                            return Card(
                              margin: const EdgeInsets.only(bottom: 12),
                              child: Column(
                                children: [
                                  ListTile(
                                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                    leading: Container(
                                      width: 44,
                                      height: 44,
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFE3F2FD),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: const Icon(Icons.location_city, color: Color(0xFF1565C0), size: 22),
                                    ),
                                    title: Text(
                                      div.name,
                                      style: const TextStyle(fontWeight: FontWeight.w700),
                                    ),
                                    subtitle: Text('${wards.length} Kata', style: const TextStyle(color: AppTheme.textMuted)),
                                    trailing: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        TextButton.icon(
                                          onPressed: () => _showAddEdit(divisionId: div.id),
                                          icon: const Icon(Icons.add, size: 16),
                                          label: const Text('Kata'),
                                          style: TextButton.styleFrom(foregroundColor: AppTheme.primaryGreen),
                                        ),
                                        IconButton(
                                          onPressed: () => setState(() {
                                            if (isExpanded) {
                                              _expandedDivisions.remove(div.id);
                                            } else {
                                              _expandedDivisions.add(div.id!);
                                            }
                                          }),
                                          icon: Icon(isExpanded ? Icons.expand_less : Icons.expand_more),
                                        ),
                                      ],
                                    ),
                                  ),
                                  if (isExpanded)
                                    Container(
                                      color: const Color(0xFFF9FAF9),
                                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                                      child: wards.isEmpty
                                          ? const Padding(
                                              padding: EdgeInsets.all(16),
                                              child: Text(
                                                'Hakuna Kata katika Tarafa hii',
                                                style: TextStyle(color: AppTheme.textMuted, fontStyle: FontStyle.italic),
                                              ),
                                            )
                                          : Column(
                                              children: wards.map((ward) => _WardTile(
                                                ward: ward,
                                                isExpanded: _expandedWardId == ward.id,
                                                onToggle: () => setState(() {
                                                  _expandedWardId = _expandedWardId == ward.id ? null : ward.id;
                                                }),
                                                onEdit: () => _showAddEdit(ward: ward),
                                                onDelete: () => _deleteWard(ward),
                                              )).toList(),
                                            ),
                                    ),
                                ],
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WardTile extends StatelessWidget {
  final Ward ward;
  final bool isExpanded;
  final VoidCallback onToggle;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _WardTile({
    required this.ward,
    required this.isExpanded,
    required this.onToggle,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          margin: const EdgeInsets.only(top: 8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey.shade200),
          ),
          child: ListTile(
            dense: true,
            leading: const Icon(Icons.map, color: Color(0xFF1565C0), size: 18),
            title: Text(ward.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(onPressed: onEdit, icon: const Icon(Icons.edit_outlined, size: 18), color: AppTheme.primaryGreen),
                IconButton(onPressed: onDelete, icon: const Icon(Icons.delete_outline, size: 18), color: AppTheme.errorRed),
                IconButton(onPressed: onToggle, icon: Icon(isExpanded ? Icons.expand_less : Icons.expand_more, size: 18)),
              ],
            ),
          ),
        ),
        if (isExpanded)
          _WardLeadersPanel(wardId: ward.id!),
      ],
    );
  }
}

class _WardLeadersPanel extends StatefulWidget {
  final int wardId;
  const _WardLeadersPanel({required this.wardId});

  @override
  State<_WardLeadersPanel> createState() => _WardLeadersPanelState();
}

class _WardLeadersPanelState extends State<_WardLeadersPanel> {
  List<Leader> _leaders = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final leaders = await DatabaseHelper.instance.getLeaders(widget.wardId, 'ward');
    if (mounted) setState(() { _leaders = leaders; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 16),
      padding: const EdgeInsets.all(12),
      child: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: _leaders.map((leader) => LeaderTile(
                leader: leader,
                onEdit: () => showDialog(
                  context: context,
                  builder: (_) => LeaderEditDialog(leader: leader, onSaved: _load),
                ),
              )).toList(),
            ),
    );
  }
}

// ─── Ward Form Dialog ────────────────────────────────────────────────────────
class _WardFormDialog extends StatefulWidget {
  final Ward? ward;
  final List<Division> divisions;
  final int initialDivisionId;
  final VoidCallback onSaved;

  const _WardFormDialog({
    this.ward,
    required this.divisions,
    required this.initialDivisionId,
    required this.onSaved,
  });

  @override
  State<_WardFormDialog> createState() => _WardFormDialogState();
}

class _WardFormDialogState extends State<_WardFormDialog> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameCtrl;
  late TextEditingController _descCtrl;
  late int _selectedDivisionId;
  bool _saving = false;

  bool get _isEdit => widget.ward != null;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.ward?.name ?? '');
    _descCtrl = TextEditingController(text: widget.ward?.description ?? '');
    _selectedDivisionId = widget.initialDivisionId;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      if (_isEdit) {
        await DatabaseHelper.instance.updateWard(
          widget.ward!.copyWith(
            name: _nameCtrl.text.trim(),
            divisionId: _selectedDivisionId,
            description: _descCtrl.text.trim().isEmpty ? null : _descCtrl.text.trim(),
          ),
        );
      } else {
        await DatabaseHelper.instance.insertWard(
          Ward(
            divisionId: _selectedDivisionId,
            name: _nameCtrl.text.trim(),
            description: _descCtrl.text.trim().isEmpty ? null : _descCtrl.text.trim(),
            createdAt: DateTime.now(),
          ),
        );
      }
      if (mounted) {
        widget.onSaved();
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text(AppStrings.savedSuccess)),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 480),
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _isEdit ? 'Hariri Kata' : 'Ongeza Kata',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 24),
                DropdownButtonFormField<int>(
                  value: _selectedDivisionId,
                  decoration: const InputDecoration(
                    labelText: 'Tarafa *',
                    prefixIcon: Icon(Icons.location_city_outlined),
                  ),
                  items: widget.divisions.map((div) => DropdownMenuItem(
                    value: div.id,
                    child: Text(div.name),
                  )).toList(),
                  onChanged: (v) => setState(() => _selectedDivisionId = v!),
                  validator: (v) => v == null ? 'Chagua Tarafa' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Jina la Kata *',
                    prefixIcon: Icon(Icons.map_outlined),
                  ),
                  textCapitalization: TextCapitalization.words,
                  validator: (v) => Validators.validateRequired(v, 'Jina la Kata'),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Maelezo (Hiari)',
                    prefixIcon: Icon(Icons.notes_outlined),
                  ),
                  maxLines: 2,
                ),
                const SizedBox(height: 28),
                Row(
                  children: [
                    Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('Ghairi'))),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _saving ? null : _save,
                        child: _saving
                            ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                            : Text(_isEdit ? 'Hifadhi' : 'Ongeza'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
