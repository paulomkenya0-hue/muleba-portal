import 'package:flutter/material.dart';
import '../../database/database_helper.dart';
import '../../models/models.dart';
import '../../theme/app_theme.dart';
import '../../utils/validators.dart';
import '../../widgets/common_widgets.dart';
import '../../widgets/leader_edit_dialog.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  List<Division> _divisions = [];
  List<Ward> _wards = [];
  Division? _selectedDivision;
  Ward? _selectedWard;
  List<SearchResult> _results = [];
  bool _searched = false;
  bool _searching = false;

  @override
  void initState() {
    super.initState();
    _loadFilters();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadFilters() async {
    final divisions = await DatabaseHelper.instance.getDivisions();
    if (mounted) setState(() => _divisions = divisions);
  }

  Future<void> _loadWards(Division? div) async {
    if (div == null) {
      setState(() { _wards = []; _selectedWard = null; });
      return;
    }
    final wards = await DatabaseHelper.instance.getWardsByDivision(div.id!);
    if (mounted) setState(() { _wards = wards; _selectedWard = null; });
  }

  Future<void> _search() async {
    setState(() => _searching = true);
    final results = await DatabaseHelper.instance.searchLeaders(
      name: _nameCtrl.text.trim().isEmpty ? null : _nameCtrl.text.trim(),
      phone: _phoneCtrl.text.trim().isEmpty ? null : _phoneCtrl.text.trim(),
      divisionId: _selectedDivision?.id,
      wardId: _selectedWard?.id,
    );
    if (mounted) setState(() {
      _results = results;
      _searched = true;
      _searching = false;
    });
  }

  void _clearFilters() {
    _nameCtrl.clear();
    _phoneCtrl.clear();
    setState(() {
      _selectedDivision = null;
      _selectedWard = null;
      _wards = [];
      _results = [];
      _searched = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceWhite,
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionHeader(title: 'Tafuta Kiongozi'),
            const SizedBox(height: 16),
            // Search filters card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: _nameCtrl,
                            decoration: const InputDecoration(
                              labelText: 'Tafuta kwa Jina',
                              prefixIcon: Icon(Icons.person_search_outlined),
                              hintText: 'Andika jina la kiongozi...',
                            ),
                            onFieldSubmitted: (_) => _search(),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: TextFormField(
                            controller: _phoneCtrl,
                            decoration: const InputDecoration(
                              labelText: 'Tafuta kwa Simu',
                              prefixIcon: Icon(Icons.phone_outlined),
                              hintText: '0712345678',
                            ),
                            keyboardType: TextInputType.phone,
                            onFieldSubmitted: (_) => _search(),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<Division>(
                            value: _selectedDivision,
                            decoration: const InputDecoration(
                              labelText: 'Chuja kwa Tarafa',
                              prefixIcon: Icon(Icons.location_city_outlined),
                            ),
                            items: [
                              const DropdownMenuItem<Division>(
                                value: null,
                                child: Text('Tarafa Zote'),
                              ),
                              ..._divisions.map((d) => DropdownMenuItem(
                                value: d,
                                child: Text(d.name),
                              )),
                            ],
                            onChanged: (d) {
                              setState(() => _selectedDivision = d);
                              _loadWards(d);
                            },
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: DropdownButtonFormField<Ward>(
                            value: _selectedWard,
                            decoration: const InputDecoration(
                              labelText: 'Chuja kwa Kata',
                              prefixIcon: Icon(Icons.map_outlined),
                            ),
                            items: [
                              const DropdownMenuItem<Ward>(
                                value: null,
                                child: Text('Kata Zote'),
                              ),
                              ..._wards.map((w) => DropdownMenuItem(
                                value: w,
                                child: Text(w.name),
                              )),
                            ],
                            onChanged: _selectedDivision == null
                                ? null
                                : (w) => setState(() => _selectedWard = w),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        TextButton.icon(
                          onPressed: _clearFilters,
                          icon: const Icon(Icons.clear),
                          label: const Text('Futa Vichujio'),
                        ),
                        const Spacer(),
                        ElevatedButton.icon(
                          onPressed: _searching ? null : _search,
                          icon: _searching
                              ? const SizedBox(height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                              : const Icon(Icons.search, size: 18),
                          label: const Text('Tafuta'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Results
            if (_searched)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(
                  'Matokeo: ${_results.length} kiongozi',
                  style: const TextStyle(color: AppTheme.textMuted, fontSize: 13),
                ),
              ),
            Expanded(
              child: !_searched
                  ? const EmptyState(
                      message: 'Weka maneno ya kutafuta na bonyeza "Tafuta"',
                      icon: Icons.manage_search,
                    )
                  : _results.isEmpty
                      ? const EmptyState(
                          message: AppStrings.noResults,
                          icon: Icons.search_off,
                        )
                      : ListView.builder(
                          itemCount: _results.length,
                          itemBuilder: (context, i) {
                            final result = _results[i];
                            return _SearchResultCard(
                              result: result,
                              onEdit: () => showDialog(
                                context: context,
                                builder: (_) => LeaderEditDialog(
                                  leader: result.leader,
                                  onSaved: _search,
                                ),
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SearchResultCard extends StatelessWidget {
  final SearchResult result;
  final VoidCallback onEdit;

  const _SearchResultCard({required this.result, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    final leader = result.leader;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: CircleAvatar(
          backgroundColor: AppTheme.lightGreen,
          child: Text(
            leader.fullName.isNotEmpty ? leader.fullName[0].toUpperCase() : '?',
            style: const TextStyle(color: AppTheme.primaryGreen, fontWeight: FontWeight.w700),
          ),
        ),
        title: Text(leader.fullName, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(leader.positionName, style: const TextStyle(color: AppTheme.primaryGreen, fontSize: 13)),
            const SizedBox(height: 2),
            Row(
              children: [
                const Icon(Icons.location_on, size: 12, color: AppTheme.textMuted),
                const SizedBox(width: 4),
                Text(
                  result.divisionName != null
                      ? '${result.divisionName} › ${result.levelName}'
                      : result.levelName,
                  style: const TextStyle(fontSize: 12, color: AppTheme.textMuted),
                ),
              ],
            ),
            if (leader.phoneNumber.isNotEmpty)
              Row(
                children: [
                  const Icon(Icons.phone, size: 12, color: AppTheme.textMuted),
                  const SizedBox(width: 4),
                  Text(leader.phoneNumber, style: const TextStyle(fontSize: 12, color: AppTheme.textMuted)),
                ],
              ),
          ],
        ),
        trailing: Chip(
          label: Text(
            leader.levelType == 'district'
                ? 'Wilaya'
                : leader.levelType == 'division'
                    ? 'Tarafa'
                    : 'Kata',
          ),
          padding: EdgeInsets.zero,
        ),
        onTap: onEdit,
      ),
    );
  }
}
