import 'package:flutter/material.dart';
import '../../database/database_helper.dart';
import '../../theme/app_theme.dart';
import '../../utils/validators.dart';
import '../../widgets/common_widgets.dart';
import '../auth/login_screen.dart';
import '../auth/change_password_screen.dart';
import '../district/district_screen.dart';
import '../division/divisions_screen.dart';
import '../ward/wards_screen.dart';
import '../search/search_screen.dart';
import '../reports/reports_screen.dart';
import '../backup/backup_screen.dart';

class DashboardScreen extends StatefulWidget {
  final String username;

  const DashboardScreen({super.key, required this.username});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;
  Map<String, int> _stats = {'divisions': 0, 'wards': 0, 'leaders': 0};

  final List<_NavItem> _navItems = const [
    _NavItem(icon: Icons.dashboard_outlined, activeIcon: Icons.dashboard, label: 'Dashibodi'),
    _NavItem(icon: Icons.account_balance_outlined, activeIcon: Icons.account_balance, label: 'Wilaya'),
    _NavItem(icon: Icons.location_city_outlined, activeIcon: Icons.location_city, label: 'Tarafa'),
    _NavItem(icon: Icons.map_outlined, activeIcon: Icons.map, label: 'Kata'),
    _NavItem(icon: Icons.search_outlined, activeIcon: Icons.search, label: 'Tafuta'),
    _NavItem(icon: Icons.bar_chart_outlined, activeIcon: Icons.bar_chart, label: 'Ripoti'),
    _NavItem(icon: Icons.backup_outlined, activeIcon: Icons.backup, label: 'Hifadhi'),
  ];

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final stats = await DatabaseHelper.instance.getStatistics();
    if (mounted) setState(() => _stats = stats);
  }

  Widget _buildCurrentScreen() {
    switch (_selectedIndex) {
      case 0:
        return _DashboardHome(stats: _stats, onNavigate: (i) => setState(() => _selectedIndex = i));
      case 1:
        return const DistrictScreen();
      case 2:
        return const DivisionsScreen();
      case 3:
        return const WardsScreen();
      case 4:
        return const SearchScreen();
      case 5:
        return const ReportsScreen();
      case 6:
        return const BackupScreen();
      default:
        return const SizedBox();
    }
  }

  void _logout() async {
    final confirm = await showConfirmDialog(
      context,
      title: 'Toka',
      message: 'Una uhakika wa kutaka kutoka?',
      confirmText: 'Toka',
      confirmColor: AppTheme.primaryGreen,
    );
    if (confirm == true && mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          // Navigation Rail
          Container(
            width: 80,
            color: AppTheme.darkNavy,
            child: Column(
              children: [
                const SizedBox(height: 16),
                // Logo
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppTheme.accentGold,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.account_balance, color: AppTheme.textDark, size: 24),
                ),
                const SizedBox(height: 24),
                Expanded(
                  child: ListView.builder(
                    itemCount: _navItems.length,
                    itemBuilder: (context, index) {
                      final item = _navItems[index];
                      final isSelected = _selectedIndex == index;
                      return Tooltip(
                        message: item.label,
                        preferBelow: false,
                        child: GestureDetector(
                          onTap: () {
                            setState(() => _selectedIndex = index);
                            if (index == 2 || index == 3) _loadStats();
                          },
                          child: Container(
                            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            decoration: BoxDecoration(
                              color: isSelected ? const Color(0xFF2A3A4A) : Colors.transparent,
                              borderRadius: BorderRadius.circular(12),
                              border: isSelected
                                  ? const Border(
                                      left: BorderSide(color: AppTheme.accentGold, width: 3),
                                    )
                                  : null,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  isSelected ? item.activeIcon : item.icon,
                                  color: isSelected ? AppTheme.accentGold : Colors.white54,
                                  size: 24,
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  item.label,
                                  style: TextStyle(
                                    fontSize: 9,
                                    color: isSelected ? AppTheme.accentGold : Colors.white38,
                                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                                  ),
                                  textAlign: TextAlign.center,
                                  maxLines: 2,
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                // Bottom actions
                Tooltip(
                  message: 'Badilisha Nywila',
                  child: IconButton(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => ChangePasswordScreen(username: widget.username)),
                    ),
                    icon: const Icon(Icons.settings_outlined, color: Colors.white38, size: 22),
                  ),
                ),
                Tooltip(
                  message: 'Toka',
                  child: IconButton(
                    onPressed: _logout,
                    icon: const Icon(Icons.logout, color: Colors.white38, size: 22),
                  ),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
          // Main content
          Expanded(
            child: Column(
              children: [
                // Top bar
                Container(
                  height: 60,
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  color: Colors.white,
                  child: Row(
                    children: [
                      const Icon(Icons.account_balance, color: AppTheme.primaryGreen, size: 20),
                      const SizedBox(width: 8),
                      const Text(
                        'WILAYA YA MULEBA',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: AppTheme.primaryGreen,
                          fontSize: 16,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppTheme.lightGreen,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.person, color: AppTheme.primaryGreen, size: 16),
                            const SizedBox(width: 6),
                            Text(
                              widget.username,
                              style: const TextStyle(
                                color: AppTheme.primaryGreen,
                                fontWeight: FontWeight.w600,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1),
                // Screen content
                Expanded(child: _buildCurrentScreen()),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final IconData activeIcon;
  final String label;

  const _NavItem({required this.icon, required this.activeIcon, required this.label});
}

// ─── Dashboard Home ──────────────────────────────────────────────────────────
class _DashboardHome extends StatelessWidget {
  final Map<String, int> stats;
  final Function(int) onNavigate;

  const _DashboardHome({required this.stats, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Welcome banner
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppTheme.primaryGreen, Color(0xFF2E7D32)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Habari za Wilaya ya Muleba',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Mfumo wa Usimamizi wa Viongozi — Offline',
                        style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 14),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.account_balance, color: Colors.white24, size: 64),
              ],
            ),
          ),
          const SizedBox(height: 28),
          SectionHeader(title: 'Muhtasari wa Takwimu'),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 1.3,
            children: [
              StatCard(
                title: 'Tarafa',
                count: stats['divisions'] ?? 0,
                icon: Icons.location_city,
                color: AppTheme.primaryGreen,
                onTap: () => onNavigate(2),
              ),
              StatCard(
                title: 'Kata',
                count: stats['wards'] ?? 0,
                icon: Icons.map,
                color: const Color(0xFF1565C0),
                onTap: () => onNavigate(3),
              ),
              StatCard(
                title: 'Viongozi',
                count: stats['leaders'] ?? 0,
                icon: Icons.people,
                color: const Color(0xFF6A1B9A),
                onTap: () => onNavigate(4),
              ),
              StatCard(
                title: 'Ngazi za Uongozi',
                count: 6,
                icon: Icons.workspace_premium,
                color: AppTheme.accentGold,
              ),
            ],
          ),
          const SizedBox(height: 28),
          SectionHeader(title: 'Ufikiaji wa Haraka'),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 3,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 2.2,
            children: [
              _QuickAction(
                icon: Icons.account_balance,
                label: 'Viongozi wa Wilaya',
                onTap: () => onNavigate(1),
              ),
              _QuickAction(
                icon: Icons.add_business,
                label: 'Ongeza Tarafa',
                onTap: () => onNavigate(2),
              ),
              _QuickAction(
                icon: Icons.add_location,
                label: 'Ongeza Kata',
                onTap: () => onNavigate(3),
              ),
              _QuickAction(
                icon: Icons.search,
                label: 'Tafuta Kiongozi',
                onTap: () => onNavigate(4),
              ),
              _QuickAction(
                icon: Icons.file_download,
                label: 'Hamisha Excel',
                onTap: () => onNavigate(5),
              ),
              _QuickAction(
                icon: Icons.backup,
                label: 'Nakala Kumbukumbu',
                onTap: () => onNavigate(6),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _QuickAction({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              Icon(icon, color: AppTheme.primaryGreen, size: 22),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: AppTheme.textDark,
                  ),
                ),
              ),
              const Icon(Icons.chevron_right, color: AppTheme.textMuted, size: 18),
            ],
          ),
        ),
      ),
    );
  }
}
