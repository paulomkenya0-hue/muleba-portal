import 'dart:io';
import 'package:flutter/material.dart';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:intl/intl.dart';
import '../../database/database_helper.dart';
import '../../models/models.dart';
import '../../theme/app_theme.dart';
import '../../utils/validators.dart';
import '../../widgets/common_widgets.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  bool _exporting = false;
  Map<String, int>? _stats;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final stats = await DatabaseHelper.instance.getStatistics();
    if (mounted) setState(() => _stats = stats);
  }

  Future<void> _exportAll() => _export('Viongozi Wote', null);
  Future<void> _exportDistrict() => _export('Wilaya', 'district');
  Future<void> _exportDivision() => _export('Tarafa', 'division');
  Future<void> _exportWard() => _export('Kata', 'ward');

  Future<void> _export(String reportType, String? levelFilter) async {
    setState(() => _exporting = true);
    try {
      List<Map<String, dynamic>> rows = await DatabaseHelper.instance.getAllLeadersForExport();
      if (levelFilter != null) {
        // For level filter mapping
        final levelMap = {'district': 'Wilaya', 'division': 'Tarafa', 'ward': 'Kata'};
        rows = rows.where((r) => r['Ngazi'] == levelMap[levelFilter]).toList();
      }

      if (rows.isEmpty) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Hakuna data ya kuhamisha')),
        );
        return;
      }

      final excel = Excel.createExcel();
      final sheet = excel['Viongozi'];
      excel.delete('Sheet1');

      // Headers with styling
      final headers = ['Ngazi', 'Jina la Eneo', 'Tarafa', 'Cheo', 'Jina Kamili', 'Simu', 'Barua Pepe'];
      for (int col = 0; col < headers.length; col++) {
        final cell = sheet.cell(CellIndex.indexByColumnRow(columnIndex: col, rowIndex: 0));
        cell.value = TextCellValue(headers[col]);
        cell.cellStyle = CellStyle(
          bold: true,
          backgroundColorHex: ExcelColor.fromHexString('#1B5E20'),
          fontColorHex: ExcelColor.fromHexString('#FFFFFF'),
        );
      }

      // Data rows
      for (int row = 0; row < rows.length; row++) {
        final data = rows[row];
        for (int col = 0; col < headers.length; col++) {
          final cell = sheet.cell(CellIndex.indexByColumnRow(columnIndex: col, rowIndex: row + 1));
          cell.value = TextCellValue(data[headers[col]]?.toString() ?? '');
          if (row % 2 == 0) {
            cell.cellStyle = CellStyle(backgroundColorHex: ExcelColor.fromHexString('#F1F8E9'));
          }
        }
      }

      // Column widths
      sheet.setColumnWidth(0, 10);
      sheet.setColumnWidth(1, 25);
      sheet.setColumnWidth(2, 25);
      sheet.setColumnWidth(3, 35);
      sheet.setColumnWidth(4, 30);
      sheet.setColumnWidth(5, 15);
      sheet.setColumnWidth(6, 30);

      // Save file
      final dir = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
      final dateStr = DateFormat('yyyyMMdd_HHmm').format(DateTime.now());
      final filename = 'Muleba_Viongozi_${reportType.replaceAll(' ', '_')}_$dateStr.xlsx';
      final file = File('${dir.path}/$filename');
      await file.writeAsBytes(excel.encode()!);

      if (!mounted) return;

      // Share the file
      await Share.shareXFiles(
        [XFile(file.path)],
        subject: 'Ripoti ya Viongozi — Wilaya ya Muleba',
        text: 'Ripoti ya $reportType — Wilaya ya Muleba\nTarehe: ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now())}',
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${AppStrings.exportSuccess} — $filename')),
      );
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Hitilafu: $e'), backgroundColor: AppTheme.errorRed),
      );
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceWhite,
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SectionHeader(title: 'Ripoti na Hamisha Excel'),
                const SizedBox(height: 16),
                // Stats summary
                if (_stats != null)
                  Row(
                    children: [
                      _StatChip(label: 'Tarafa', count: _stats!['divisions'] ?? 0, color: AppTheme.primaryGreen),
                      const SizedBox(width: 12),
                      _StatChip(label: 'Kata', count: _stats!['wards'] ?? 0, color: const Color(0xFF1565C0)),
                      const SizedBox(width: 12),
                      _StatChip(label: 'Viongozi', count: _stats!['leaders'] ?? 0, color: const Color(0xFF6A1B9A)),
                    ],
                  ),
                const SizedBox(height: 24),
                // Export options
                Expanded(
                  child: GridView.count(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    childAspectRatio: 1.6,
                    children: [
                      _ExportCard(
                        title: 'Viongozi Wote',
                        subtitle: 'Hamisha viongozi wa Wilaya, Tarafa na Kata wote',
                        icon: Icons.people,
                        color: AppTheme.primaryGreen,
                        onTap: _exportAll,
                      ),
                      _ExportCard(
                        title: 'Viongozi wa Wilaya',
                        subtitle: 'Viongozi 6 wa Wilaya ya Muleba',
                        icon: Icons.account_balance,
                        color: const Color(0xFFF9A825),
                        onTap: _exportDistrict,
                      ),
                      _ExportCard(
                        title: 'Viongozi wa Tarafa',
                        subtitle: 'Viongozi wa Tarafa zote',
                        icon: Icons.location_city,
                        color: const Color(0xFF1565C0),
                        onTap: _exportDivision,
                      ),
                      _ExportCard(
                        title: 'Viongozi wa Kata',
                        subtitle: 'Viongozi wa Kata zote',
                        icon: Icons.map,
                        color: const Color(0xFF6A1B9A),
                        onTap: _exportWard,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.lightGreen,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppTheme.dividerGreen.withOpacity(0.4)),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.info_outline, color: AppTheme.primaryGreen, size: 18),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Faili la Excel litahifadhiwa na pia litashirikiwa moja kwa moja. Unaweza kulifungua kwa Microsoft Excel au Google Sheets.',
                          style: TextStyle(color: AppTheme.primaryGreen, fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (_exporting) const LoadingOverlay(message: 'Inaandaa ripoti...'),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final int count;
  final Color color;

  const _StatChip({required this.label, required this.count, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            count.toString(),
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: color),
          ),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}

class _ExportCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _ExportCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(icon, color: color, size: 24),
                  ),
                  const Spacer(),
                  const Icon(Icons.file_download_outlined, color: AppTheme.textMuted, size: 20),
                ],
              ),
              const Spacer(),
              Text(
                title,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: const TextStyle(color: AppTheme.textMuted, fontSize: 12),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
