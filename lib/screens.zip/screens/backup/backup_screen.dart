import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:intl/intl.dart';
import '../../database/database_helper.dart';
import '../../theme/app_theme.dart';
import '../../utils/validators.dart';
import '../../widgets/common_widgets.dart';

class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  bool _loading = false;
  String? _lastBackupPath;

  Future<void> _backup() async {
    setState(() => _loading = true);
    try {
      final dir = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
      final dateStr = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
      final backupPath = '${dir.path}/muleba_backup_$dateStr.db';

      final success = await DatabaseHelper.instance.backupDatabase(backupPath);
      if (!mounted) return;

      if (success) {
        setState(() => _lastBackupPath = backupPath);
        // Share the backup file
        await Share.shareXFiles(
          [XFile(backupPath)],
          subject: 'Nakala ya Database — Wilaya ya Muleba',
          text: 'Nakala kumbukumbu ya mfumo — ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now())}',
        );
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text(AppStrings.backupSuccess)),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text(AppStrings.errorOccurred), backgroundColor: AppTheme.errorRed),
        );
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Hitilafu: $e'), backgroundColor: AppTheme.errorRed),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _restore() async {
    // Confirm first
    final confirm = await showConfirmDialog(
      context,
      title: 'Rejesha Taarifa',
      message: 'TAHADHARI: Kurejesha database itafuta data yote ya sasa na kuibadilisha na data ya nakala.\n\nUna uhakika wa kuendelea?',
      confirmText: 'Rejesha',
      confirmColor: Colors.orange,
    );
    if (confirm != true) return;

    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.any,
        allowMultiple: false,
      );

      if (result == null || result.files.isEmpty) return;
      final pickedFile = result.files.first;
      if (pickedFile.path == null) return;

      // Verify it's a .db file
      if (!pickedFile.name.endsWith('.db')) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tafadhali chagua faili la .db tu'), backgroundColor: AppTheme.errorRed),
        );
        return;
      }

      setState(() => _loading = true);
      final success = await DatabaseHelper.instance.restoreDatabase(pickedFile.path!);
      if (!mounted) return;

      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text(AppStrings.restoreSuccess)),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text(AppStrings.errorOccurred), backgroundColor: AppTheme.errorRed),
        );
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Hitilafu: $e'), backgroundColor: AppTheme.errorRed),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceWhite,
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SectionHeader(title: 'Hifadhi na Rejesha Data'),
                const SizedBox(height: 24),
                // Backup card
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: AppTheme.lightGreen,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Icon(Icons.backup, color: AppTheme.primaryGreen, size: 28),
                            ),
                            const SizedBox(width: 16),
                            const Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Nakala Kumbukumbu',
                                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                                ),
                                Text(
                                  'Hifadhi data yote kwa usalama',
                                  style: TextStyle(color: AppTheme.textMuted),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          'Chaguo hili litahifadhi nakala ya database yote ya mfumo. Unaweza kuhifadhi faili hili katika simu au kutuma kwa barua pepe kwa usalama.',
                          style: TextStyle(color: AppTheme.textMuted, fontSize: 14, height: 1.5),
                        ),
                        if (_lastBackupPath != null) ...[
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: AppTheme.lightGreen,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.check_circle, color: AppTheme.primaryGreen, size: 16),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    'Nakala ya mwisho: ${_lastBackupPath!.split('/').last}',
                                    style: const TextStyle(color: AppTheme.primaryGreen, fontSize: 12),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: _loading ? null : _backup,
                            icon: const Icon(Icons.cloud_download_outlined),
                            label: const Text('Tengeneza Nakala Sasa'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                // Restore card
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.orange.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Icon(Icons.restore, color: Colors.orange, size: 28),
                            ),
                            const SizedBox(width: 16),
                            const Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Rejesha Taarifa',
                                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                                ),
                                Text(
                                  'Rejesha data kutoka kwa nakala',
                                  style: TextStyle(color: AppTheme.textMuted),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.orange.withOpacity(0.08),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.orange.withOpacity(0.3)),
                          ),
                          child: const Row(
                            children: [
                              Icon(Icons.warning_amber, color: Colors.orange, size: 18),
                              SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  'TAHADHARI: Kurejesha kutafuta data yote ya sasa. Hakikisha una nakala ya hali ya sasa kabla ya kuendelea.',
                                  style: TextStyle(color: Colors.orange, fontSize: 13, height: 1.4),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        const Text(
                          'Chagua faili la .db kutoka kwa hifadhi ya simu au SD card. Faili hilo lazima liwe nakala iliyotengenezwa na mfumo huu.',
                          style: TextStyle(color: AppTheme.textMuted, fontSize: 14, height: 1.5),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: _loading ? null : _restore,
                            icon: const Icon(Icons.folder_open_outlined),
                            label: const Text('Chagua Faili la Nakala'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.orange,
                              side: const BorderSide(color: Colors.orange),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                // Info
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF3F4F6),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Maelekezo ya Hifadhi:',
                        style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                      ),
                      SizedBox(height: 8),
                      _InfoRow('Tengeneza nakala kila wiki kwa usalama wa data'),
                      _InfoRow('Hifadhi nakala katika mahali tofauti (email, cloud)'),
                      _InfoRow('Lipa kipaumbele kwa nakala kabla ya kubadilisha data nyingi'),
                      _InfoRow('Faili la nakala lina muundo: muleba_backup_YYYYMMDD.db'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (_loading) const LoadingOverlay(message: 'Inafanya kazi...'),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String text;
  const _InfoRow(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('• ', style: TextStyle(color: AppTheme.primaryGreen, fontWeight: FontWeight.w700)),
          Expanded(child: Text(text, style: const TextStyle(color: AppTheme.textMuted, fontSize: 13))),
        ],
      ),
    );
  }
}
